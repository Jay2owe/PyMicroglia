"""Group occupied coordinates once while preserving row-major cell geometry."""
from contextlib import contextmanager
import numpy as np


def groups(frame):
    yy, xx = np.nonzero(frame > 0)
    if not len(yy):
        return
    values = frame[yy, xx]
    order = np.argsort(values, kind='stable')
    ordered = values[order]
    boundaries = np.r_[0, np.flatnonzero(ordered[1:] != ordered[:-1])+1, len(order)]
    for first,last in zip(boundaries[:-1],boundaries[1:]):
        indices = order[first:last]
        yield int(ordered[first]), yy[indices], xx[indices]


@contextmanager
def grouped_geometry(density, cyclic):
    old_density, old_cyclic = density._objects, cyclic._objects
    def density_objects(frame):
        if frame.ndim != 2 or frame.dtype.kind not in 'iu':
            return old_density(frame)
        result = {}
        for identity, yy, xx in groups(frame):
            mask = np.zeros(frame.shape, dtype=bool);mask[yy,xx] = True
            y0,y1,x0,x1 = int(yy.min()),int(yy.max())+1,int(xx.min()),int(xx.max())+1
            result[identity] = dict(mask=mask,area=int(len(xx)),y=float(yy.mean()),x=float(xx.mean()),
                radius=float(np.sqrt(len(xx)/np.pi)),components=int(density.ndi.label(mask[y0:y1,x0:x1],density.STRUCTURE)[1]),
                first_y=int(yy[0]),first_x=int(xx[0]))
        return result
    def cyclic_objects(labels):
        if labels.ndim != 3 or labels.dtype.kind not in 'iu':
            return old_cyclic(labels)
        result = []
        for frame in labels:
            row = {}
            for identity, yy, xx in groups(frame):
                mask = np.zeros(frame.shape,dtype=bool);mask[yy,xx] = True
                area=int(len(yy));cy,cx=float(yy.mean()),float(xx.mean())
                centred=frozenset(zip(np.rint(yy-cy).astype(int).tolist(),np.rint(xx-cx).astype(int).tolist()))
                row[identity]=dict(mask=mask,area=area,y=cy,x=cx,radius=float(np.sqrt(area/np.pi)),centred=centred)
            result.append(row)
        return result
    density._objects, cyclic._objects = density_objects, cyclic_objects
    try:
        yield
    finally:
        density._objects, cyclic._objects = old_density, old_cyclic
