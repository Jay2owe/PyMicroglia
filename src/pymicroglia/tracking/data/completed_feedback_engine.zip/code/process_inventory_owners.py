"""Original measurements; array inputs, no feedback lookup or file I/O."""
from __future__ import annotations
import heapq
import numpy as np
import pandas as pd
from scipy import ndimage as ndi
from scipy.spatial import cKDTree
import separable_merge_recovery as physical
from separable_merge_recovery import attach_owners
STRUCTURE = np.ones((3, 3), bool)
OFFSETS = [(dy, dx) for dy in range(-2, 3) for dx in range(-2, 3) if dy*dy+dx*dx <= 4]


def switches(group: pd.DataFrame, t: int, small: int, large: int, radius: int) -> dict:
    near = group[(group.frame.astype(int).between(t-radius, t+radius))
                 & group.physically_visible.astype(bool)]
    owners = near.accepted_owner.astype(int)
    before = near[near.frame.astype(int) < t].accepted_owner.astype(int)
    after = near[near.frame.astype(int) > t].accepted_owner.astype(int)
    return {
        f"visible_window_{radius}": len(owners),
        f"large_owner_window_{radius}": int(owners.eq(large).sum()),
        f"small_owner_window_{radius}": int(owners.eq(small).sum()),
        f"large_owner_before_{radius}": int(before.eq(large).sum()),
        f"large_owner_after_{radius}": int(after.eq(large).sum()),
    }

def scan(movies: dict, source: pd.DataFrame | None = None) -> pd.DataFrame:
    rows = []
    for well, group in source.groupby("well", sort=True):
        labels = movies[well]["embedded_labels"]
        points = movies[well]["points"]
        ownership = attach_owners(points, labels)
        tracks = {int(k): v for k, v in ownership.groupby("track_id")}
        for pair in group.itertuples(index=False):
            row = pair._asdict()
            track = row["small_track"]
            if not np.isfinite(track) or int(track) not in tracks:
                rows.append(row)
                continue
            for radius in (3, 7, 15):
                row.update(switches(tracks[int(track)], int(pair.frame)-1,
                                    int(pair.small_identity), int(pair.large_identity), radius))
            rows.append(row)
        print(well, "tracks", len(tracks), flush=True)

    return pd.DataFrame(rows)
