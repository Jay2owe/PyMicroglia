"""Recover a sustained missing soma after an independently named track run.

The field-wide producer receives no feedback, coordinates, names, or selected
recordings. It only adds a raw-supported body to previously empty pixels;
every accepted named pixel remains byte-identical.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import ndimage as ndi

import separable_merge_recovery as physical


STRUCTURE = np.ones((3, 3), np.uint8)


@dataclass(frozen=True)
class Params:
    minimum_reference_run_frames: int = 10
    minimum_ownerless_run_frames: int = 10
    maximum_reference_gap_frames: int = 1
    minimum_strong_fraction: float = .9
    minimum_median_peak_retention: float = .7
    minimum_median_core_area_ratio: float = .45
    minimum_median_core_retention: float = .7
    minimum_frame_peak_retention: float = .4
    maximum_core_area_ratio: float = 2.0
    minimum_application_fraction: float = .8
    core_peak_fraction: float = .35


def _consecutive_runs(rows: pd.DataFrame) -> list[pd.DataFrame]:
    rows = rows.sort_values("frame")
    if rows.empty:
        return []
    boundaries = np.flatnonzero(np.diff(rows.frame.astype(int).to_numpy()) != 1) + 1
    return [rows.loc[indices] for indices in np.split(rows.index.to_numpy(), boundaries)
            if len(indices)]


def _reference(group: pd.DataFrame, onset: int) -> tuple[int, pd.DataFrame]:
    early = group[(group.frame.astype(int) < onset)
                  & group.physically_visible.astype(bool)
                  & group.strong.astype(bool)
                  & ~group.in_encounter.astype(bool)
                  & group.state.astype(str).eq("observed")
                  & group.accepted_owner.astype(int).gt(0)]
    best_owner, best = 0, early.iloc[0:0]
    for owner, owned in early.groupby("accepted_owner", sort=True):
        for run in _consecutive_runs(owned):
            if len(run) > len(best) or (len(run) == len(best) and len(run)
                                       and int(run.frame.max()) > int(best.frame.max())):
                best_owner, best = int(owner), run
    return best_owner, best


def _core(raw_frame: np.ndarray, point, peak_fraction: float
          ) -> tuple[np.ndarray, tuple[slice, slice], float, float]:
    radius = max(2.0, float(point.radius_px))
    extent = int(np.ceil(2 * radius))
    y, x = float(point.y), float(point.x)
    y0, y1 = max(0, int(y) - extent), min(raw_frame.shape[0], int(y) + extent + 1)
    x0, x1 = max(0, int(x) - extent), min(raw_frame.shape[1], int(x) + extent + 1)
    region = slice(y0, y1), slice(x0, x1)
    local = raw_frame[region]
    yy, xx = np.ogrid[y0:y1, x0:x1]
    distance = np.hypot(yy - y, xx - x)
    near = distance <= radius
    peak = float(np.max(local[near]))
    if peak <= 0:
        return np.zeros_like(local, bool), region, 0.0, 0.0
    seed_y, seed_x = np.argwhere((local == peak) & near)[0]
    binary = (distance <= 2 * radius) & (local >= peak_fraction * peak) & (local > 0)
    components, _ = ndi.label(binary, STRUCTURE)
    component = int(components[seed_y, seed_x])
    core = components == component if component else np.zeros_like(binary)
    area_ratio = float(np.count_nonzero(core) / (np.pi * max(float(point.radius_px), 1) ** 2))
    return core, region, peak, area_ratio


def correct(labels: np.ndarray, unclaimed: np.ndarray, raw: np.ndarray,
            points: pd.DataFrame, params: Params = Params()
            ) -> tuple[np.ndarray, np.ndarray, pd.DataFrame, pd.DataFrame]:
    if labels.shape != raw.shape or labels.shape != unclaimed.shape:
        raise ValueError("raw, labels and unclaimed ledger must align")
    scored = physical.attach_owners(points, labels)
    for field in ("strong", "physically_visible", "in_encounter"):
        scored[field] = scored[field].astype(bool)
    by_frame = {int(t): group for t, group in scored.groupby("frame")}
    proposals = []
    for track, group in scored.groupby("track_id", sort=True):
        visible = group[group.physically_visible]
        zero = visible[visible.accepted_owner.astype(int).eq(0)]
        for episode in _consecutive_runs(zero):
            if len(episode) < params.minimum_ownerless_run_frames:
                continue
            onset = int(episode.frame.min())
            owner, reference = _reference(group, onset)
            if (owner <= 0 or len(reference) < params.minimum_reference_run_frames
                    or onset - int(reference.frame.max()) - 1 > params.maximum_reference_gap_frames
                    or float(episode.strong.mean()) < params.minimum_strong_fraction):
                continue
            reference_raw = [_core(raw[int(row.frame)], row, params.core_peak_fraction)
                             for row in reference.itertuples(index=False)]
            median_peak = float(np.median([item[2] for item in reference_raw]))
            median_area = float(np.median([item[3] for item in reference_raw]))
            episode_raw = [_core(raw[int(row.frame)], row, params.core_peak_fraction)
                           for row in episode.itertuples(index=False)]
            median_peak_retention = float(np.median(
                [item[2] / max(median_peak, 1) for item in episode_raw]))
            median_core_area_ratio = float(np.median([item[3] for item in episode_raw]))
            median_core_retention = median_core_area_ratio / max(median_area, .01)
            if (median_peak_retention < params.minimum_median_peak_retention
                    or median_core_area_ratio < params.minimum_median_core_area_ratio
                    or median_core_retention < params.minimum_median_core_retention):
                continue
            proposals.append((int(track), owner, episode, median_peak,
                              median_peak_retention, median_core_area_ratio,
                              median_core_retention, episode_raw))

    candidate, candidate_unclaimed = labels.copy(), unclaimed.copy()
    audits, applications = [], []
    for (track, owner, episode, reference_peak, peak_retention, area_ratio,
         area_retention, episode_raw) in proposals:
        selected, refusals = [], []
        for row, (core, region, peak, core_ratio) in zip(
                episode.itertuples(index=False), episode_raw):
            t = int(row.frame)
            reason = None
            if not np.any(core) or core_ratio > params.maximum_core_area_ratio:
                reason = "core_area_invalid"
            elif peak / max(reference_peak, 1) < params.minimum_frame_peak_retention:
                reason = "raw_peak_too_dim"
            elif np.any(candidate[t][region][core] > 0):
                reason = "core_touches_existing_outline"
            elif np.any(candidate[t] == owner):
                reason = "identity_on_other_body"
            else:
                for other in by_frame.get(t, scored.iloc[0:0]).itertuples(index=False):
                    if int(other.track_id) == track or not bool(other.physically_visible):
                        continue
                    yy = int(np.clip(round(float(other.y)), 0, labels.shape[1] - 1))
                    xx = int(np.clip(round(float(other.x)), 0, labels.shape[2] - 1))
                    if region[0].start <= yy < region[0].stop and region[1].start <= xx < region[1].stop:
                        if core[yy - region[0].start, xx - region[1].start]:
                            reason = "other_physical_point_in_core"
                            break
            if reason is None:
                selected.append((t, core, region, peak, core_ratio))
            else:
                refusals.append(f"{t + 1}:{reason}")
        if len(selected) / len(episode) < params.minimum_application_fraction:
            audits.append({
                "track_id": track, "reference_owner": owner,
                "first_frame": int(episode.frame.min()) + 1,
                "last_frame": int(episode.frame.max()) + 1,
                "visible_episode_frames": len(episode),
                "selected_frames": len(selected),
                "median_peak_retention": peak_retention,
                "median_core_area_radius_ratio": area_ratio,
                "median_core_area_retention": area_retention,
                "status": "insufficient_safe_frame_coverage",
                "refusals": "|".join(refusals),
            })
            continue
        for t, core, region, peak, core_ratio in selected:
            selected_pixels = int(np.count_nonzero(core))
            candidate[t][region][core] = owner
            candidate_unclaimed[t][region][core] = 0
            applications.append({
                "track_id": track, "reference_owner": owner,
                "frame": t + 1, "added_pixels": selected_pixels,
                "raw_peak": peak, "core_area_radius_ratio": core_ratio,
            })
        audits.append({
            "track_id": track, "reference_owner": owner,
            "first_frame": int(episode.frame.min()) + 1,
            "last_frame": int(episode.frame.max()) + 1,
            "visible_episode_frames": len(episode),
            "selected_frames": len(selected),
            "median_peak_retention": peak_retention,
            "median_core_area_radius_ratio": area_ratio,
            "median_core_area_retention": area_retention,
            "status": "applied",
            "refusals": "|".join(refusals),
        })
    changed = candidate != labels
    if (np.any(changed & (labels != 0))
            or np.any((candidate_unclaimed != unclaimed) & ~changed)
            or not np.array_equal(np.unique(candidate), np.unique(labels))):
        raise AssertionError("ownerless-soma layer crossed an accepted label boundary")
    return candidate, candidate_unclaimed, pd.DataFrame(audits), pd.DataFrame(applications)
