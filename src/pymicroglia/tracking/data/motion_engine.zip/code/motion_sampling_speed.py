"""Reuse exact local motion maxima during the existing immutable-frame linker."""
from contextlib import contextmanager
import numpy as np
from scipy import ndimage as ndi


@contextmanager
def cached_motion_samples(module):
    original=module._motion_support_plane
    cache={}
    weights=np.linspace(0.,1.,7)
    previous_weights=1-weights
    def support(plane,x0,y0,x1,y1):
        if plane is None:return original(plane,x0,y0,x1,y1)
        if plane.dtype.kind not in 'biuf' or (plane.dtype.kind=='f' and plane.dtype.itemsize not in (4,8)):
            return original(plane,x0,y0,x1,y1)
        if cache.get('plane') is not plane:
            finite=bool(np.isfinite(plane).all())
            cache.clear();cache.update(plane=plane,finite=finite)
            if finite:
                fill=np.iinfo(plane.dtype).min if plane.dtype.kind in 'iu' else (-np.inf if plane.dtype.kind=='f' else 0)
                padded=np.pad(plane,1,mode='constant',constant_values=fill)
                cache['maxima']=ndi.maximum_filter(padded,size=3,mode='constant',cval=fill)
        if not cache['finite'] or not np.isfinite([x0,y0,x1,y1]).all():return original(plane,x0,y0,x1,y1)
        x=np.rint(previous_weights*x0+weights*x1)
        y=np.rint(previous_weights*y0+weights*y1)
        valid=(x>=-1)&(x<=plane.shape[1])&(y>=-1)&(y<=plane.shape[0])
        if not valid.any():value=0.
        else:value=float(np.max(cache['maxima'][y[valid].astype(np.intp)+1,x[valid].astype(np.intp)+1]))
        return float(np.clip(value/65535.,0.,1.))
    module._motion_support_plane=support
    try:yield
    finally:module._motion_support_plane=original
