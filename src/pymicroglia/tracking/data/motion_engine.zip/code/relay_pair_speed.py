"""Avoid impossible frame intersections and batch unchanged pair arithmetic."""
import ast
from contextlib import contextmanager
from pathlib import Path
import numpy as np


def frame_bits(arrays):
    if not arrays:
        return {}
    lower = min(int(v['frame'].min()) for v in arrays.values())
    upper = max(int(v['frame'].max()) for v in arrays.values())
    # Execution-memory bound only. Larger ranges retain the original search.
    if upper-lower > 65536:
        return {}
    result = {}
    for track, values in arrays.items():
        frames = values['frame']
        if len(np.unique(frames)) != len(frames):
            continue  # Preserve original assume_unique behavior for duplicates.
        bits = 0
        for frame in frames:
            bits |= 1 << (int(frame)-lower)
        result[track] = bits
    return result


def possible_overlap(bits, left, right, minimum):
    if left not in bits or right not in bits:
        return True
    return (bits[left] & bits[right]).bit_count() >= minimum


def finite_vector_median(values):
    array=np.asarray(values)
    if array.ndim!=1 or array.dtype!=np.dtype('float64') or not array.size or not np.isfinite(array).all():
        return np.median(values)
    middle=array.size//2
    indices=[middle] if array.size%2 else [middle-1,middle]
    partitioned=np.partition(array,indices)
    # Same NumPy mean and central order as median, including signed zeros.
    return np.mean(partitioned[indices[0]:indices[-1]+1])



def pair_summary_builder(arrays, summarize):
    # Private to one discovery. Track arrays are immutable during discovery.
    # Bounded tail cache changes execution work only; eviction recomputes exactly.
    from collections import OrderedDict
    full = {}
    tails = OrderedDict()
    def describe(frames, owners):
        summary = summarize(frames, owners)
        positive = np.flatnonzero(owners > 0)
        edges = None if not len(positive) else (
            frames[positive[0]], int(owners[positive[0]]),
            frames[positive[-1]], int(owners[positive[-1]]))
        return summary, edges
    def pair(left_track, right_track):
        left, right = arrays[left_track], arrays[right_track]
        if (int(left['frame'][0]), int(left['frame'][-1])) <= (int(right['frame'][0]), int(right['frame'][-1])):
            predecessor, successor = left_track, right_track
        else:
            predecessor, successor = right_track, left_track
        first, second = arrays[predecessor], arrays[successor]
        if predecessor not in full:
            full[predecessor] = describe(first['frame'], first['owner'])
        cut = int(first['frame'][-1]); key = (successor, cut)
        if key not in tails:
            select = second['frame'] > cut
            tails[key] = describe(second['frame'][select], second['owner'][select])
            if len(tails) > 4096:
                tails.popitem(last=False)
        else:
            tails.move_to_end(key)
        (a, ae), (b, be) = full[predecessor], tails[key]
        if ae is None:
            return b
        if be is None:
            return a
        with np.errstate(over='ignore'):
            joined = ae[3] == be[1] and be[0] == np.int64(ae[2]) + np.int64(1)
        counts = a[1].copy(); counts.update(b[1])
        runs = {owner: values.copy() for owner, values in a[2].items()}
        for owner, values in b[2].items():
            runs.setdefault(owner, []).extend(values[1:] if joined and owner == be[1] else values)
        return a[0] + b[0] - int(joined), counts, runs
    return pair


@contextmanager
def faster_relay_pairs(module):
    original = module.discover
    tree = ast.parse(Path(module.__file__).read_text())
    function = next(v for v in tree.body if isinstance(v, ast.FunctionDef) and v.name == 'discover')
    arrays = [v for v in function.body if isinstance(v, ast.Assign) and ast.unparse(v.targets[0]) == 'arrays']
    assert len(arrays) == 1
    at = function.body.index(arrays[0])+1
    function.body[at:at] = ast.parse('_frame_bits = _make_frame_bits(arrays)\n_pair_summary = _make_pair_summary(arrays, _owner_run_summary)').body
    pairs = [v for v in ast.walk(function) if isinstance(v, ast.For) and ast.unparse(v.target) == 'right_track']
    assert len(pairs) == 1
    pairs[0].body[0:0] = ast.parse('if not _possible_overlap(_frame_bits, left_track, right_track, minimum_overlap):\n    continue').body
    inner = [v for v in pairs[0].body if isinstance(v, ast.For) and ast.unparse(v.target) == '(left_row, right_row)']
    assert len(inner) == 1
    index = pairs[0].body.index(inner[0])
    replacement = ast.parse('''same_owner = (left['owner'][left_indices] > 0) & (left['owner'][left_indices] == right['owner'][right_indices])
scale = np.maximum(left['radius'][left_indices] + right['radius'][right_indices], 1.0)
separations = np.hypot(left['x'][left_indices] - right['x'][right_indices], left['y'][left_indices] - right['y'][right_indices]) / scale
''').body
    pairs[0].body[index:index+1] = replacement
    medians=[node for node in ast.walk(function) if isinstance(node,ast.Call) and ast.unparse(node.func)=='np.median' and len(node.args)==1 and ast.unparse(node.args[0])=='separations']
    assert len(medians)==1,'Pair median call changed; equivalence review required'
    medians[0].func=ast.Name(id='_finite_vector_median',ctx=ast.Load())
    summaries=[node for node in ast.walk(function) if isinstance(node,ast.Call) and ast.unparse(node.func)=='_owner_run_summary' and [ast.unparse(arg) for arg in node.args]==['virtual_frames','virtual_owners']]
    assert len(summaries)==1
    summaries[0].func=ast.Name(id='_pair_summary',ctx=ast.Load())
    summaries[0].args=[ast.Name(id='left_track',ctx=ast.Load()),ast.Name(id='right_track',ctx=ast.Load())]
    namespace = dict(vars(module));namespace.update(_make_pair_summary=pair_summary_builder, _make_frame_bits=frame_bits, _possible_overlap=possible_overlap, _finite_vector_median=finite_vector_median)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[function],type_ignores=[])),str(module.__file__)+'::pair_speed','exec'),namespace)
    module.discover = namespace['discover']
    try:
        yield
    finally:
        module.discover = original
