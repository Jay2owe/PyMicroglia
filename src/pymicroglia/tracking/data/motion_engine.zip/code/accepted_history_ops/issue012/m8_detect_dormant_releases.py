"""Detect weak-name takeovers and mass-conserving dormant releases."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy import ndimage as ndi

from project_paths import find_project_root


ROOT = find_project_root(Path(__file__))
sys.path.insert(0, str(ROOT / "code"))
from common import load_stack  # noqa: E402


STRUCTURE = np.ones((3, 3), bool)


def components(frame: np.ndarray, identity: int,
               minimum_area: int = 8) -> list[dict]:
    numbered, count = ndi.label(frame == identity, structure=STRUCTURE)
    result = []
    for number in range(1, count + 1):
        mask = numbered == number
        area = int(mask.sum())
        if area < minimum_area:
            continue
        centre = np.argwhere(mask).mean(axis=0)
        result.append({"component": number, "mask": mask, "area": area,
                       "y": float(centre[0]), "x": float(centre[1])})
    return result


def largest(frame: np.ndarray, identity: int,
            minimum_area: int = 8) -> dict | None:
    found = components(frame, identity, minimum_area)
    return max(found, key=lambda item: item["area"]) if found else None


def history(labels: np.ndarray, raw: np.ndarray, identity: int,
            source_frame: int, offset: int, window: int,
            minimum_area: int) -> tuple[list[int], list[float]]:
    areas, intensities = [], []
    first_source = offset + 1
    for source in range(max(first_source, source_frame - window), source_frame):
        index = source - offset - 1
        item = largest(labels[index], identity, minimum_area)
        if item is not None:
            areas.append(item["area"])
            intensities.append(float(raw[index][item["mask"]].mean()))
    return areas, intensities


def persistence(labels: np.ndarray, identity: int, source_frame: int,
                centre: np.ndarray, offset: int, minimum_area: int,
                frames: int = 3, radius: float = 35.0) -> int:
    found = 1
    previous = centre
    for source in range(source_frame + 1,
                        min(source_frame + frames, offset + len(labels)) + 1):
        index = source - offset - 1
        choices = components(labels[index], identity, minimum_area)
        if not choices:
            break
        item = min(choices, key=lambda part: float(np.linalg.norm(
            np.array([part["y"], part["x"]]) - previous)))
        current = np.array([item["y"], item["x"]])
        if float(np.linalg.norm(current - previous)) > radius:
            break
        found += 1
        previous = current
    return found


def detect(labels: np.ndarray, raw: np.ndarray, lag: np.ndarray,
           actions: pd.DataFrame, offset: int, cfg: dict
           ) -> tuple[pd.DataFrame, pd.DataFrame]:
    if actions.empty:
        return pd.DataFrame(), pd.DataFrame()
    if "action" not in actions.columns:
        raise ValueError("nonempty action table has no action column")
    minimum_area = int(cfg.get("minimum_component_area_px", 8))
    history_window = int(cfg.get("history_window_frames", 6))
    first_source = offset + 1
    last_source = offset + len(labels)
    starts = actions[actions.action.astype(str) == "dormancy_started"].copy()
    starts = starts.sort_values("source_imagej_frame").drop_duplicates(
        ["prior_identity", "host_identity"], keep="first")
    events: list[dict] = []
    releases: list[dict] = []

    for row in starts.itertuples(index=False):
        start = int(row.source_imagej_frame)
        identity = int(row.prior_identity)
        host = int(row.host_identity)
        d_areas, d_raw = history(labels, raw, identity, start, offset,
                                 history_window, minimum_area)
        h_areas, _ = history(labels, raw, host, start, offset,
                             history_window, minimum_area)
        established = float(np.median(d_areas)) if d_areas else 0.0
        established_raw = float(np.median(d_raw)) if d_raw else 0.0
        large_floor = float(cfg.get("established_area_floor_px", 80))
        d_large = sum(area >= large_floor for area in d_areas)
        h_large = sum(area >= large_floor for area in h_areas)
        previous_host = float(h_areas[-1]) if h_areas else 0.0
        current_host = largest(labels[start - offset - 1], host, minimum_area)
        current_host_area = float(current_host["area"]) if current_host else 0.0
        host_ratio = previous_host / max(current_host_area, 1.0)
        current_to_established = current_host_area / max(established, 1.0)
        weak_takeover = bool(
            d_large >= int(cfg.get("minimum_established_history_frames", 3))
            and established >= float(cfg.get(
                "minimum_takeover_established_area_px", 150))
            and h_large < int(cfg.get("minimum_host_history_frames", 3))
            and host_ratio <= float(cfg.get(
                "maximum_weak_host_previous_area_ratio", 0.2))
            and current_to_established <= float(cfg.get(
                "maximum_takeover_area_ratio", 1.8)))
        event_type = "weak_name_takeover" if weak_takeover else "true_dormancy"
        event_id = f"{event_type}_{identity}_{host}_{start}"
        events.append({
            "event_id": event_id, "event_type": event_type,
            "identity": identity, "host_identity": host,
            "start_source_imagej_frame": start,
            "established_area_px": established,
            "established_raw_mean": established_raw,
            "identity_large_history_frames": d_large,
            "host_large_history_frames": h_large,
            "previous_host_area_px": previous_host,
            "current_host_area_px": current_host_area,
            "previous_to_current_host_area_ratio": host_ratio,
        })
        if weak_takeover or established <= 0:
            continue

        # Enumerate permissively. The next stage applies every grid threshold.
        for source in range(start + 1, last_source + 1):
            prior_index = source - offset - 2
            index = source - offset - 1
            prior_host = largest(labels[prior_index], host, minimum_area)
            current_host = largest(labels[index], host, minimum_area)
            if prior_host is None:
                continue
            current_area = current_host["area"] if current_host else 0
            host_loss = max(0, prior_host["area"] - current_area)
            if host_loss / max(established, 1.0) < float(
                    cfg.get("enumeration_minimum_host_loss_ratio", 0.3)):
                continue
            host_centre = np.array([
                current_host["y"], current_host["x"]]) if current_host else np.array([
                    prior_host["y"], prior_host["x"]])
            for candidate_identity in sorted(
                    set(map(int, np.unique(labels[index]))) - {0, host, identity}):
                for part in components(labels[index], candidate_identity,
                                       minimum_area):
                    centre = np.array([part["y"], part["x"]])
                    distance = float(np.linalg.norm(centre - host_centre))
                    if distance > float(cfg.get(
                            "enumeration_maximum_radius_px", 60)):
                        continue
                    area_ratio = part["area"] / max(established, 1.0)
                    if not float(cfg.get("minimum_candidate_area_ratio", 0.25)) <= area_ratio <= float(cfg.get("maximum_candidate_area_ratio", 2.0)):
                        continue
                    prior_local = 0
                    for old_source in range(max(first_source, source - 10), source):
                        old_index = old_source - offset - 1
                        for old in components(labels[old_index], candidate_identity,
                                              minimum_area):
                            old_centre = np.array([old["y"], old["x"]])
                            if float(np.linalg.norm(old_centre - centre)) <= 35:
                                prior_local = max(prior_local, old["area"])
                    red = float(np.mean(lag[prior_index][part["mask"]] >= float(
                        cfg.get("motion_threshold", 1.5))))
                    mass_match = 1.0 - abs(part["area"] - host_loss) / max(
                        part["area"], host_loss, 1)
                    releases.append({
                        "event_id": event_id, "identity": identity,
                        "host_identity": host,
                        "release_source_imagej_frame": source,
                        "candidate_identity": candidate_identity,
                        "candidate_component": int(part["component"]),
                        "candidate_area_px": int(part["area"]),
                        "candidate_y": float(part["y"]),
                        "candidate_x": float(part["x"]),
                        "host_loss_px": int(host_loss),
                        "host_loss_to_established_ratio": host_loss / max(established, 1.0),
                        "candidate_to_established_area_ratio": area_ratio,
                        "mass_match": mass_match,
                        "distance_from_host_px": distance,
                        "red_arrival_fraction": red,
                        "persistence_frames": persistence(
                            labels, candidate_identity, source, centre, offset,
                            minimum_area),
                        "prior_local_max_area_px": prior_local,
                        "prior_local_to_established_ratio": prior_local / max(established, 1.0),
                    })
    return pd.DataFrame(events), pd.DataFrame(releases)
