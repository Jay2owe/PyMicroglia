"""Apply composable Issue 017 continuity repairs inside frozen foreground support."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import tifffile


PROJECT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(PROJECT / "code"))
from persistent_merges import _split_interval  # noqa: E402
from presence import complete_presence, complete_presence_bidirectional  # noqa: E402


def _aligned_movies(labels: np.ndarray, raw_path: Path, lag_path: Path,
                    source_frame_offset: int) -> tuple[np.ndarray, np.ndarray]:
    raw_full = tifffile.imread(raw_path)
    lag_full = tifffile.imread(lag_path)
    start = int(source_frame_offset)
    raw = raw_full[start:start + len(labels)]
    lag = lag_full[start:start + len(labels) - 1]
    if raw.shape != labels.shape or lag.shape[0] != len(labels) - 1:
        raise ValueError(
            f"aligned evidence differs from labels: labels={labels.shape}, "
            f"raw={raw.shape}, lag={lag.shape}")
    return raw, lag


def _frame_index(source_frame: int, source_frame_offset: int) -> int:
    return int(source_frame) - int(source_frame_offset) - 1


def _presence_params(intervals: list[dict], *, bracketed: bool) -> dict:
    return {
        "forced_intervals": intervals,
        "limit_to_observed_lifetime": bool(bracketed),
        "minimum_persistent_area_px": 12,
        "minimum_persistent_observations": 3,
        "allow_field_exit": True,
        "carve_hosts": True,
        "carve_only_new_host_gain": False,
    }


def _restore_locked(candidate: np.ndarray, baseline: np.ndarray,
                    locked_ids: set[int]) -> np.ndarray:
    """Make locked identity masks byte-identical, including removal of new pixels."""
    if not locked_ids:
        return candidate
    locked_before = np.isin(baseline, list(locked_ids))
    locked_after = np.isin(candidate, list(locked_ids))
    candidate = candidate.copy()
    candidate[locked_before | locked_after] = baseline[locked_before | locked_after]
    return candidate


def _account_foreground(candidate: np.ndarray, baseline: np.ndarray,
                        baseline_unclaimed: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Keep assigned plus explicit unclaimed pixels equal to the parent union."""
    foreground = (baseline > 0) | (baseline_unclaimed > 0)
    candidate = candidate.copy()
    candidate[~foreground] = 0
    unclaimed = np.where(candidate == 0, baseline_unclaimed, 0).astype(
        baseline_unclaimed.dtype, copy=False)
    if not np.array_equal((candidate > 0) | (unclaimed > 0), foreground):
        raise AssertionError("candidate foreground accounting differs from parent")
    if np.any((candidate > 0) & (unclaimed > 0)):
        raise AssertionError("candidate assigned and unclaimed masks overlap")
    return candidate, unclaimed


def _action_rows(before: np.ndarray, after: np.ndarray, evidence: pd.DataFrame,
                 approach: str, source_frame_offset: int) -> list[dict]:
    rows: list[dict] = []
    for row in evidence.itertuples(index=False):
        identity = int(row.identity)
        start = _frame_index(row.gap_start_source_frame, source_frame_offset)
        end = _frame_index(row.gap_end_source_frame, source_frame_offset)
        recovered = [t for t in range(start, end + 1)
                     if not np.any(before[t] == identity)
                     and np.any(after[t] == identity)]
        changed = sum(int(np.count_nonzero(before[t] != after[t]))
                      for t in range(start, end + 1))
        rows.append({
            "approach": approach,
            "identity": identity,
            "mechanism": str(row.mechanism),
            "gap_start_source_frame": int(row.gap_start_source_frame),
            "gap_end_source_frame": int(row.gap_end_source_frame),
            "requested_frames": int(row.missing_frames),
            "recovered_frames": len(recovered),
            "changed_pixels": changed,
            "status": "recovered" if len(recovered) == int(row.missing_frames)
                      else "partial" if recovered else "unresolved",
        })
    return rows


def _bracketed_recovery(labels: np.ndarray, raw: np.ndarray, lag: np.ndarray,
                        evidence: pd.DataFrame, source_frame_offset: int,
                        locked_ids: set[int]) -> tuple[np.ndarray, pd.DataFrame, list[dict]]:
    targets = evidence[
        evidence.mechanism.astype(str).isin(
            ["local_raw_supported_dropout", "blue_red_motion_link_candidate"])
        & ~evidence.identity.astype(int).isin(locked_ids)
    ].copy()
    intervals = [{
        "identity": int(row.identity),
        "start_t": _frame_index(row.gap_start_source_frame, source_frame_offset),
        "end_t": _frame_index(row.gap_end_source_frame, source_frame_offset),
    } for row in targets.itertuples(index=False)]
    if not intervals:
        return labels.copy(), pd.DataFrame(), []
    candidate, _, attempts = complete_presence_bidirectional(
        labels, raw, lag, _presence_params(intervals, bracketed=True))
    return candidate, attempts, _action_rows(
        labels, candidate, targets, "R_bracketed_recovery", source_frame_offset)


def _merge_continuation(labels: np.ndarray, raw: np.ndarray, lag: np.ndarray,
                        evidence: pd.DataFrame, source_frame_offset: int,
                        merge_params: dict, locked_ids: set[int],
                        excluded_ids: set[int] | None = None,
                        ) -> tuple[np.ndarray, list[dict]]:
    excluded_ids = (excluded_ids or set()) | locked_ids
    candidate = labels.copy()
    targets = evidence[
        (evidence.mechanism.astype(str) == "same_host_merge_hiding")
        & ~evidence.identity.astype(int).isin(excluded_ids)
    ].sort_values(["gap_start_source_frame", "identity"])
    actions: list[dict] = []
    for row in targets.itertuples(index=False):
        identity = int(row.identity)
        hosts = [int(row.next_owner), int(row.prior_owner)]
        host = next((value for value in hosts if value > 0), 0)
        start = _frame_index(row.gap_start_source_frame, source_frame_offset)
        future = _frame_index(row.post_source_frame, source_frame_offset)
        before = candidate.copy()
        result = None if host in excluded_ids or not host else _split_interval(
            candidate, raw, lag, start, future, identity, host, merge_params)
        if result is not None:
            candidate, _ = result
        action = _action_rows(
            before, candidate, pd.DataFrame([row._asdict()]),
            "M_merge_slot_continuation", source_frame_offset)[0]
        action["host_identity"] = host
        actions.append(action)
    return candidate, actions


def _ending_search(labels: np.ndarray, raw: np.ndarray, lag: np.ndarray,
                   terminations: pd.DataFrame, source_frame_offset: int,
                   locked_ids: set[int]) -> tuple[np.ndarray, pd.DataFrame, list[dict]]:
    targets = terminations[
        (terminations.mechanism.astype(str) == "silent_no_foreground")
        & ~terminations.identity.astype(int).isin(locked_ids)
    ].copy()
    intervals = [{
        "identity": int(row.identity),
        "start_t": _frame_index(row.last_source_frame, source_frame_offset) + 1,
        "end_t": len(labels) - 1,
    } for row in targets.itertuples(index=False)]
    if not intervals:
        return labels.copy(), pd.DataFrame(), []
    candidate, _, attempts = complete_presence(
        labels, raw, lag, _presence_params(intervals, bracketed=False))
    actions: list[dict] = []
    for row in targets.itertuples(index=False):
        identity = int(row.identity)
        start = _frame_index(row.last_source_frame, source_frame_offset) + 1
        recovered = sum(np.any(candidate[t] == identity) for t in range(start, len(labels)))
        present = np.flatnonzero(np.any(candidate == identity, axis=(1, 2)))
        last = int(present[-1])
        mask = candidate[last] == identity
        border = bool(mask[0].any() or mask[-1].any()
                      or mask[:, 0].any() or mask[:, -1].any())
        status = ("reaches_movie_end" if last == len(labels) - 1 else
                  "supported_border_exit" if border else "flagged_unresolved_ending")
        actions.append({
            "approach": "E_end_of_track_search",
            "identity": identity,
            "mechanism": "silent_no_foreground",
            "gap_start_source_frame": int(row.last_source_frame) + 1,
            "gap_end_source_frame": len(labels) + source_frame_offset,
            "requested_frames": len(labels) - start,
            "recovered_frames": int(recovered),
            "changed_pixels": int(np.count_nonzero(
                labels[start:] != candidate[start:])),
            "status": status,
        })
    return candidate, attempts, actions


def _truncate_to_contiguous_end_path(
        before: np.ndarray, candidate: np.ndarray,
        terminations: pd.DataFrame, source_frame_offset: int,
        locked_ids: set[int],
        ) -> tuple[np.ndarray, list[dict], list[dict]]:
    """Keep only the uninterrupted recovered prefix after each real ending."""
    targets = terminations[
        (terminations.mechanism.astype(str) == "silent_no_foreground")
        & ~terminations.identity.astype(int).isin(locked_ids)
    ]
    output = candidate.copy()
    actions: list[dict] = []
    flags: list[dict] = []
    for row in targets.itertuples(index=False):
        identity = int(row.identity)
        start = _frame_index(row.last_source_frame, source_frame_offset) + 1
        stop = start
        while stop < len(output) and np.any(output[stop] == identity):
            stop += 1
        for t in range(stop, len(output)):
            invented = (output[t] == identity) & (before[t] != identity)
            output[t][invented] = before[t][invented]
        present = np.flatnonzero(np.any(output == identity, axis=(1, 2)))
        last = int(present[-1])
        mask = output[last] == identity
        border = bool(mask[0].any() or mask[-1].any()
                      or mask[:, 0].any() or mask[:, -1].any())
        if last == len(output) - 1:
            status = "reaches_movie_end_continuously"
        elif border:
            status = "supported_border_exit_continuously"
        else:
            status = "flagged_at_first_unresolved_frame"
            flags.append({
                "flag_type": "unresolved_nonborder_ending",
                "identity": identity,
                "start_source_frame": last + source_frame_offset + 2,
                "end_source_frame": len(output) + source_frame_offset,
                "reason": "continuous search stopped at first unsupported frame",
            })
        actions.append({
            "approach": "E_contiguous_end_search",
            "identity": identity,
            "mechanism": "silent_no_foreground",
            "gap_start_source_frame": int(row.last_source_frame) + 1,
            "gap_end_source_frame": len(output) + source_frame_offset,
            "requested_frames": len(output) - start,
            "recovered_frames": max(0, last - start + 1),
            "changed_pixels": int(np.count_nonzero(before != output)),
            "status": status,
        })
    return output, actions, flags


def _long_gap_audit(labels: np.ndarray, evidence: pd.DataFrame,
                    source_frame_offset: int, locked_ids: set[int]
                    ) -> tuple[list[dict], list[dict]]:
    targets = evidence[
        (evidence.missing_frames.astype(int) > 12)
        & evidence.mechanism.astype(str).isin(
            ["distant_alias_risk", "long_unproven_gap"])
        & ~evidence.identity.astype(int).isin(locked_ids)
    ]
    actions: list[dict] = []
    flags: list[dict] = []
    for row in targets.itertuples(index=False):
        identity = int(row.identity)
        start = _frame_index(row.gap_start_source_frame, source_frame_offset)
        end = _frame_index(row.gap_end_source_frame, source_frame_offset)
        continuous = all(np.any(labels[t] == identity) for t in range(start, end + 1))
        status = "continuous_path_recovered" if continuous else "flagged_alias_risk"
        actions.append({
            "approach": "L_long_gap_audit",
            "identity": identity,
            "mechanism": str(row.mechanism),
            "gap_start_source_frame": int(row.gap_start_source_frame),
            "gap_end_source_frame": int(row.gap_end_source_frame),
            "requested_frames": int(row.missing_frames),
            "recovered_frames": int(row.missing_frames) if continuous else 0,
            "changed_pixels": 0,
            "status": status,
        })
        if not continuous:
            flags.append({
                "flag_type": "long_gap_without_continuous_path",
                "identity": identity,
                "start_source_frame": int(row.gap_start_source_frame),
                "end_source_frame": int(row.gap_end_source_frame),
                "reason": str(row.mechanism),
            })
    return actions, flags

