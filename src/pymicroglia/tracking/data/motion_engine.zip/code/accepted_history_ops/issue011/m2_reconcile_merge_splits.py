"""Reconcile post-merge identities with domain, appearance, and motion costs."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

from project_paths import find_project_root


ROOT = find_project_root(Path(__file__))
sys.path.insert(0, str(ROOT / "code"))
from common import load_stack, save_stack  # noqa: E402


def median_summary(features: pd.DataFrame, identity: int,
                   frames: list[int]) -> dict | None:
    table = features[(features.identity == identity)
                     & features.frame_index.isin(frames)]
    if table.empty:
        return None
    columns = ["centroid_y", "centroid_x", "area", "mean_intensity",
               "eccentricity", "solidity", "normalized_perimeter"]
    return {column: float(table[column].median()) for column in columns}


def overlap_coefficient(labels: np.ndarray, canonical: int, observed: int,
                        pre_frames: list[int], post_frames: list[int]) -> float:
    best = 0.0
    for pre in pre_frames:
        source = labels[pre] == canonical
        source_area = int(np.count_nonzero(source))
        if source_area == 0:
            continue
        for post in post_frames:
            destination = labels[post] == observed
            destination_area = int(np.count_nonzero(destination))
            if destination_area == 0:
                continue
            shared = int(np.count_nonzero(source & destination))
            best = max(best, shared / max(min(source_area, destination_area), 1))
    return best


def predicted_position(features: pd.DataFrame, identity: int,
                       pre_frames: list[int], target_frame: float) -> np.ndarray:
    table = features[(features.identity == identity)
                     & features.frame_index.isin(pre_frames)].sort_values(
                         "frame_index")
    if table.empty:
        return np.array([np.nan, np.nan])
    last = table.iloc[-1]
    position = np.array([last.centroid_y, last.centroid_x], float)
    if len(table) < 2:
        return position
    changes = np.diff(table[["centroid_y", "centroid_x"]].to_numpy(float), axis=0)
    velocity = np.median(changes, axis=0)
    speed = float(np.linalg.norm(velocity))
    if speed > 12.0:
        velocity *= 12.0 / speed
    horizon = min(max(target_frame - float(last.frame_index), 0.0), 3.0)
    return position + velocity * horizon


def appearance_cost(canonical: dict, observed: dict) -> float:
    eps = 1e-6
    intensity = abs(np.log2((observed["mean_intensity"] + eps)
                            / (canonical["mean_intensity"] + eps)))
    area = abs(np.log2((observed["area"] + eps) / (canonical["area"] + eps)))
    eccentricity = abs(observed["eccentricity"] - canonical["eccentricity"]) / 0.5
    solidity = abs(observed["solidity"] - canonical["solidity"]) / 0.5
    perimeter = abs(observed["normalized_perimeter"]
                    - canonical["normalized_perimeter"]) / 2.0
    return float(0.45 * intensity + 0.35 * area + 0.10 * eccentricity
                 + 0.05 * solidity + 0.05 * perimeter)


def cost_components(labels: np.ndarray, features: pd.DataFrame,
                    canonical: int, observed: int, pre: int, post: int,
                    pre_window: int, post_window: int,
                    domain_radius: float, trajectory_radius: float) -> dict | None:
    pre_frames = list(range(max(0, pre - pre_window + 1), pre + 1))
    post_frames = list(range(post, min(len(labels), post + post_window)))
    canonical_summary = median_summary(features, canonical, pre_frames)
    observed_summary = median_summary(features, observed, post_frames)
    if canonical_summary is None or observed_summary is None:
        return None
    separation = float(np.hypot(
        canonical_summary["centroid_y"] - observed_summary["centroid_y"],
        canonical_summary["centroid_x"] - observed_summary["centroid_x"]))
    overlap = overlap_coefficient(labels, canonical, observed,
                                  pre_frames, post_frames)
    domain = 0.7 * separation / domain_radius + 0.3 * (1.0 - overlap)
    target_frame = float(np.median(post_frames))
    prediction = predicted_position(features, canonical, pre_frames, target_frame)
    observed_position = np.array([
        observed_summary["centroid_y"], observed_summary["centroid_x"]])
    motion = float(np.linalg.norm(prediction - observed_position)
                   / trajectory_radius)
    result = {
        "domain": float(domain),
        "appearance": appearance_cost(canonical_summary, observed_summary),
        "motion": motion,
        "centroid_distance_px": separation,
        "territory_overlap": overlap,
    }
    return result


def selected_cost(components: dict, methods: set[str], params: dict) -> float:
    weights = {
        "D": float(params["domain_weight"]),
        "A": float(params["appearance_weight"]),
        "M": float(params["motion_weight"]),
    }
    values = {"D": components["domain"], "A": components["appearance"],
              "M": components["motion"]}
    return float(sum(weights[method] * values[method] for method in methods))


def pair_swap_candidate(labels: np.ndarray, features: pd.DataFrame,
                        event: pd.Series, companion: int, methods: set[str],
                        profile_params: dict, params: dict) -> dict | None:
    focal = int(event.identity)
    pre, post = int(event.pre_frame_index), int(event.post_frame_index)
    if str(event.get("event_type", "soft_gap")) == "soft_gap":
        start, end = (int(event.gap_start_frame_index),
                      int(event.gap_end_frame_index))
        pre_frames = list(range(max(0, pre - int(profile_params["pre_window_frames"]) + 1),
                                pre + 1))
        host_pre = median_summary(features, companion, pre_frames)
        host_gap = median_summary(features, companion, list(range(start, end + 1)))
        gap_presence = len(features[(features.identity == companion)
                                    & features.frame_index.between(start, end)])
        gap_presence /= max(end - start + 1, 1)
        if host_pre is None or host_gap is None:
            return None
        area_gain = host_gap["area"] - host_pre["area"]
        minimum_gain = (float(params["minimum_host_area_gain_fraction"])
                        * float(event.reference_area))
        if (gap_presence < float(params["minimum_host_gap_presence_fraction"])
                or area_gain < minimum_gain):
            return None
    parts: dict[tuple[int, int], dict] = {}
    for canonical in (focal, companion):
        for observed in (focal, companion):
            result = cost_components(
                labels, features, canonical, observed, pre, post,
                int(profile_params["pre_window_frames"]),
                int(profile_params["post_window_frames"]),
                float(params["domain_radius_px"]),
                float(params["trajectory_radius_px"]))
            if result is None:
                return None
            parts[(canonical, observed)] = result
    maximum_radius = float(params["maximum_action_radius_px"])
    if (parts[(focal, companion)]["centroid_distance_px"] > maximum_radius
            or parts[(companion, focal)]["centroid_distance_px"] > maximum_radius):
        return None
    current = selected_cost(parts[(focal, focal)], methods, params) + selected_cost(
        parts[(companion, companion)], methods, params)
    swapped = selected_cost(parts[(focal, companion)], methods, params) + selected_cost(
        parts[(companion, focal)], methods, params)
    improvement = current - swapped
    result = {
        "action_type": "suffix_swap",
        "event_id": event.event_id,
        "identity_a": focal,
        "identity_b": companion,
        "start_frame_index": post,
        "end_frame_index": len(labels) - 1,
        "start_source_imagej_frame": post + int(profile_params["source_frame_offset"]) + 1,
        "end_source_imagej_frame": len(labels) + int(profile_params["source_frame_offset"]),
        "current_cost": current,
        "alternative_cost": swapped,
        "cost_improvement": improvement,
        "domain_improvement": (
            parts[(focal, focal)]["domain"] + parts[(companion, companion)]["domain"]
            - parts[(focal, companion)]["domain"] - parts[(companion, focal)]["domain"]),
        "appearance_improvement": (
            parts[(focal, focal)]["appearance"] + parts[(companion, companion)]["appearance"]
            - parts[(focal, companion)]["appearance"] - parts[(companion, focal)]["appearance"]),
        "motion_improvement": (
            parts[(focal, focal)]["motion"] + parts[(companion, companion)]["motion"]
            - parts[(focal, companion)]["motion"] - parts[(companion, focal)]["motion"]),
    }
    # Appearance and velocity break close calls; neither may override evidence that
    # both cells already returned to their own pre-contact territories.
    if result["domain_improvement"] <= 0:
        return None
    return result


def relay_candidate(features: pd.DataFrame, profiles: pd.DataFrame,
                    event: pd.Series, companion: int, methods: set[str],
                    profile_params: dict, params: dict) -> dict | None:
    focal = int(event.identity)
    if str(event.get("event_type", "soft_gap")) != "soft_gap":
        return None
    companion_profile = profiles[profiles.identity == companion]
    if companion_profile.empty or bool(companion_profile.iloc[0].persistent):
        return None
    lineage_frames = int(companion_profile.iloc[0].frames_present)
    if lineage_frames > int(params["relay_maximum_lineage_frames"]):
        return None
    start, end = int(event.gap_start_frame_index), int(event.gap_end_frame_index)
    gap = list(range(start, end + 1))
    companion_gap = features[(features.identity == companion)
                             & features.frame_index.isin(gap)]
    presence = len(companion_gap) / max(len(gap), 1)
    if presence < float(params["relay_minimum_gap_fraction"]):
        return None
    pre, post = int(event.pre_frame_index), int(event.post_frame_index)
    pre_frames = list(range(max(0, pre - int(profile_params["pre_window_frames"]) + 1), pre + 1))
    post_frames = list(range(post, post + int(profile_params["post_window_frames"])))
    canonical = median_summary(features, focal, pre_frames + post_frames)
    observed = median_summary(features, companion, gap)
    if canonical is None or observed is None:
        return None
    expected_distances = []
    motion_distances = []
    prediction = predicted_position(features, focal, pre_frames, float(np.median(gap)))
    pre_summary = median_summary(features, focal, [pre])
    post_summary = median_summary(features, focal, [post])
    if pre_summary is None or post_summary is None:
        return None
    for row in companion_gap.itertuples(index=False):
        alpha = (int(row.frame_index) - pre) / max(post - pre, 1)
        expected = np.array([
            (1 - alpha) * pre_summary["centroid_y"] + alpha * post_summary["centroid_y"],
            (1 - alpha) * pre_summary["centroid_x"] + alpha * post_summary["centroid_x"],
        ])
        position = np.array([row.centroid_y, row.centroid_x])
        expected_distances.append(float(np.linalg.norm(position - expected)))
        motion_distances.append(float(np.linalg.norm(position - prediction)))
    components = {
        "domain": float(np.median(expected_distances)
                        / float(params["domain_radius_px"])),
        "appearance": appearance_cost(canonical, observed),
        "motion": float(np.median(motion_distances)
                        / float(params["trajectory_radius_px"])),
    }
    alternative = selected_cost(components, methods, params)
    missing = 1.2 * sum({"D": float(params["domain_weight"]),
                         "A": float(params["appearance_weight"]),
                         "M": float(params["motion_weight"])}[item]
                        for item in methods)
    first = int(companion_profile.iloc[0].first_source_imagej_frame) - int(
        profile_params["source_frame_offset"]) - 1
    last = int(companion_profile.iloc[0].last_source_imagej_frame) - int(
        profile_params["source_frame_offset"]) - 1
    if first < pre - 1 or last > end + 1:
        first, last = start, end
    return {
        "action_type": "gap_relay_alias",
        "event_id": event.event_id,
        "identity_a": focal,
        "identity_b": companion,
        "start_frame_index": first,
        "end_frame_index": last,
        "start_source_imagej_frame": first + int(profile_params["source_frame_offset"]) + 1,
        "end_source_imagej_frame": last + int(profile_params["source_frame_offset"]) + 1,
        "current_cost": missing,
        "alternative_cost": alternative,
        "cost_improvement": missing - alternative,
        "domain_improvement": 1.2 - components["domain"],
        "appearance_improvement": 1.2 - components["appearance"],
        "motion_improvement": 1.2 - components["motion"],
    }


def choose_actions(candidates: pd.DataFrame, minimum_improvement: float) -> pd.DataFrame:
    if candidates.empty:
        return candidates
    eligible = candidates[candidates.cost_improvement >= minimum_improvement].copy()
    eligible = eligible.sort_values(
        ["cost_improvement", "start_frame_index"], ascending=[False, True])
    chosen: list[pd.Series] = []
    occupied: dict[int, list[tuple[int, int]]] = {}
    for _, row in eligible.iterrows():
        pair = (int(row.identity_a), int(row.identity_b))
        interval = (int(row.start_frame_index), int(row.end_frame_index))
        conflict = any(
            not (interval[1] < prior[0] or interval[0] > prior[1])
            for identity in pair for prior in occupied.get(identity, []))
        if conflict:
            continue
        chosen.append(row)
        for identity in pair:
            occupied.setdefault(identity, []).append(interval)
    return pd.DataFrame(chosen, columns=candidates.columns)


def apply_actions(labels: np.ndarray, unclaimed: np.ndarray,
                  actions: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    corrected = labels.copy()
    released = unclaimed.copy()
    if actions.empty:
        return corrected, released
    for row in actions.sort_values("start_frame_index").itertuples(index=False):
        start, end = int(row.start_frame_index), int(row.end_frame_index)
        first, second = int(row.identity_a), int(row.identity_b)
        if row.action_type == "suffix_swap":
            for frame in range(start, end + 1):
                a = corrected[frame] == first
                b = corrected[frame] == second
                corrected[frame][a] = second
                corrected[frame][b] = first
        elif row.action_type == "gap_relay_alias":
            for frame in range(start, end + 1):
                corrected[frame][corrected[frame] == second] = first
        else:
            raise ValueError(f"unknown action type: {row.action_type}")
    return corrected, released

