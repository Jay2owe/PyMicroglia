"""Reassign distant secondary identity fragments using local and temporal evidence."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import ndimage as ndi

from project_paths import find_project_root


ROOT = find_project_root(Path(__file__))
sys.path.insert(0, str(ROOT / "code"))
from common import load_stack, save_stack  # noqa: E402

STRUCTURE = np.ones((3, 3), np.uint8)


def components(frame: np.ndarray, identity: int) -> list[np.ndarray]:
    parts, count = ndi.label(frame == identity, structure=STRUCTURE)
    return [parts == component for component in range(1, count + 1)]


def clean_duplicates(labels: np.ndarray, cfg: dict,
                     source_offset: int) -> tuple[np.ndarray, pd.DataFrame]:
    candidate = labels.copy()
    rows = []
    minimum = int(cfg["minimum_secondary_area_px"])
    minimum_primary_distance = float(cfg["minimum_primary_distance_px"])
    maximum_neighbour = float(cfg["maximum_neighbour_distance_px"])
    dilation = int(cfg["temporal_dilation_px"])
    for t in range(len(candidate)):
        snapshot = candidate[t].copy()
        identities = sorted(set(map(int, np.unique(snapshot))) - {0})
        for identity in identities:
            parts = components(snapshot, identity)
            eligible = [part for part in parts if int(part.sum()) >= minimum]
            if len(eligible) < 2:
                continue
            primary = max(eligible, key=lambda mask: int(mask.sum()))
            primary_distance = ndi.distance_transform_edt(~primary)
            for secondary in eligible:
                if secondary is primary:
                    continue
                separation = float(primary_distance[secondary].min())
                if separation < minimum_primary_distance:
                    continue
                secondary_distance = ndi.distance_transform_edt(~secondary)
                choices = []
                for neighbour in identities:
                    if neighbour == identity:
                        continue
                    neighbour_mask = snapshot == neighbour
                    distance = float(secondary_distance[neighbour_mask].min())
                    if distance > maximum_neighbour:
                        continue
                    region = ndi.binary_dilation(secondary, iterations=dilation)
                    temporal = 0
                    if t > 0:
                        temporal += int(np.count_nonzero(
                            (candidate[t - 1] == neighbour) & region))
                    if t + 1 < len(candidate):
                        temporal += int(np.count_nonzero(
                            (candidate[t + 1] == neighbour) & region))
                    neighbour_area = int(neighbour_mask.sum())
                    choices.append(((temporal, -distance, neighbour_area),
                                    neighbour, distance))
                if not choices:
                    continue
                score, new_identity, distance = max(choices, key=lambda row: row[0])
                if score[0] == 0 and score[2] < int(cfg.get(
                        "minimum_neighbour_area_without_temporal_px", 48)):
                    continue
                candidate[t][secondary] = int(new_identity)
                rows.append({
                    "output_frame": t + 1,
                    "source_imagej_frame": t + 1 + source_offset,
                    "old_identity": identity,
                    "new_identity": int(new_identity),
                    "area_px": int(secondary.sum()),
                    "primary_distance_px": separation,
                    "neighbour_distance_px": distance,
                    "temporal_support_px": int(score[0]),
                })
    return candidate, pd.DataFrame(rows)

