"""Find and bridge every qualified motion-supported temporary merge."""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import ndimage as ndi

from project_paths import find_project_root


ROOT = find_project_root(Path(__file__))
sys.path.insert(0, str(ROOT / "code"))
from common import load_stack, save_stack  # noqa: E402
from m3_bridge_merges import motion_partition, partition_host  # noqa: E402

STRUCTURE = np.ones((3, 3), np.uint8)


def identity_objects(frame: np.ndarray, identity: int | None = None) -> list[dict]:
    result = []
    identities = ([identity] if identity is not None
                  else sorted(set(map(int, np.unique(frame))) - {0}))
    for owner in identities:
        parts, count = ndi.label(frame == owner, structure=STRUCTURE)
        for component in range(1, count + 1):
            mask = parts == component
            yy, xx = np.nonzero(mask)
            result.append({"owner": int(owner), "mask": mask,
                           "area": int(mask.sum()),
                           "x": float(xx.mean()), "y": float(yy.mean())})
    return result


def binary_objects(frame: np.ndarray) -> list[dict]:
    parts, count = ndi.label(frame > 0, structure=STRUCTURE)
    result = []
    for component in range(1, count + 1):
        mask = parts == component
        yy, xx = np.nonzero(mask)
        values, counts = np.unique(frame[mask], return_counts=True)
        owner = int(values[int(np.argmax(counts))])
        result.append({"owner": owner, "mask": mask, "area": int(mask.sum()),
                       "x": float(xx.mean()), "y": float(yy.mean())})
    return result


def mask_distance(a: np.ndarray, b: np.ndarray) -> float:
    if np.any(a & b):
        return 0.0
    return float(ndi.distance_transform_edt(~a)[b].min())


def continuing_target(labels: np.ndarray, lag: np.ndarray, t: int,
                      target: dict, cfg: dict) -> bool:
    for item in identity_objects(labels[t + 1], target["owner"]):
        distance = math.hypot(item["x"] - target["x"],
                              item["y"] - target["y"])
        ratio = item["area"] / max(target["area"], 1)
        red = float(np.mean(lag[t][item["mask"]] >= 1.5))
        if (distance <= float(cfg["maximum_radial_distance_px"])
                and 0.25 <= ratio <= 4.0 and red >= 0.4):
            return True
    return False


def detect_events(labels: np.ndarray, lag: np.ndarray, cfg: dict,
                  source_offset: int) -> list[dict]:
    events = []
    minimum_area = int(cfg["minimum_target_area_px"])
    for t in range(len(labels) - 2):
        current_objects = identity_objects(labels[t])
        for target in current_objects:
            if target["area"] < minimum_area:
                continue
            yy, xx = np.nonzero(target["mask"])
            if min(xx.min(), yy.min(), labels.shape[2] - 1 - xx.max(),
                   labels.shape[1] - 1 - yy.max()) <= 2:
                continue
            blue = float(np.mean(lag[t][target["mask"]] <= -1.5))
            if blue < float(cfg["minimum_source_blue_coverage"]):
                continue
            if continuing_target(labels, lag, t, target, cfg):
                continue
            nearby = [item for item in current_objects
                      if item is not target and item["owner"] != target["owner"]
                      and mask_distance(target["mask"], item["mask"])
                      <= float(cfg["maximum_entry_gap_px"])]
            resident_options = []
            for resident in nearby:
                next_parts = identity_objects(labels[t + 1], resident["owner"])
                if not next_parts:
                    continue
                following = max(next_parts, key=lambda item: (
                    int(np.count_nonzero(item["mask"] & resident["mask"])),
                    item["area"]))
                gain = following["area"] - resident["area"]
                red_host = float(np.mean(lag[t][following["mask"]] >= 1.5))
                if (gain >= 0.5 * target["area"]
                        and red_host >= float(cfg["minimum_host_red_coverage"])):
                    resident_options.append(((gain, red_host), resident, following))
            if not resident_options:
                continue
            _, resident, first_host = max(resident_options,
                                          key=lambda row: row[0])
            merge_frames = [t + 1]
            hosts = {t + 1: first_host["mask"]}
            previous_host = first_host
            split_t = resident_exit = target_exit = None
            for frame in range(t + 2, min(len(labels), t + 2
                                         + int(cfg["maximum_merge_frames"]))):
                resident_parts = identity_objects(labels[frame], resident["owner"])
                if not resident_parts:
                    break
                resident_current = max(resident_parts, key=lambda item: (
                    int(np.count_nonzero(item["mask"] & previous_host["mask"])),
                    -math.hypot(item["x"] - previous_host["x"],
                                item["y"] - previous_host["y"])))
                if resident_current["area"] >= 0.55 * previous_host["area"]:
                    merge_frames.append(frame)
                    hosts[frame] = resident_current["mask"]
                    previous_host = resident_current
                    continue
                exit_options = []
                for item in binary_objects(labels[frame]):
                    if item["owner"] == resident["owner"]:
                        continue
                    distance = math.hypot(item["x"] - previous_host["x"],
                                          item["y"] - previous_host["y"])
                    ratio = item["area"] / max(target["area"], 1)
                    red = float(np.mean(lag[frame - 1][item["mask"]] >= 1.5))
                    if (distance <= float(cfg["maximum_radial_distance_px"])
                            and 0.25 <= ratio <= 4.0):
                        exit_options.append(((red, -distance), item))
                qualified_exits = [row for row in exit_options
                                   if row[0][0] >= float(
                                       cfg["minimum_exit_red_coverage"])]
                if qualified_exits:
                    # Red first qualifies a destination; distance then selects
                    # which qualified red object continues the lost source.
                    exit_score, departing = min(
                        qualified_exits, key=lambda row: (-row[0][1], -row[0][0]))
                    resident_red = float(np.mean(
                        lag[frame - 1][resident_current["mask"]] >= 1.5))
                    if (resident_red <= float(
                                cfg["maximum_resident_red_coverage"])):
                        split_t, resident_exit, target_exit = (
                            frame, resident_current, departing)
                break
            if split_t is None or target_exit is None or resident_exit is None:
                continue
            events.append({
                "target_identity": target["owner"],
                "resident_identity": resident["owner"],
                "entry_t": t,
                "merge_frames": merge_frames,
                "host_masks": hosts,
                "split_t": split_t,
                "target_entry": target,
                "resident_entry": resident,
                "target_exit": target_exit,
                "resident_exit": resident_exit,
                "source_blue_coverage": blue,
                "host_red_coverage": float(max(row[0][1]
                                                for row in resident_options)),
                "exit_red_coverage": float(np.mean(
                    lag[split_t - 1][target_exit["mask"]] >= 1.5)),
                "resident_red_coverage": float(np.mean(
                    lag[split_t - 1][resident_exit["mask"]] >= 1.5)),
                "source_entry_imagej_frame": t + 1 + source_offset,
                "source_split_imagej_frame": split_t + 1 + source_offset,
            })
    # Keep the strongest event when repeated target/resident windows overlap.
    selected = []
    occupied: dict[int, np.ndarray] = {}
    for event in sorted(events, key=lambda row: (
            row["source_blue_coverage"] + row["exit_red_coverage"]), reverse=True):
        conflict = any(frame in occupied and np.any(
            occupied[frame] & event["host_masks"][frame])
            for frame in event["merge_frames"])
        if conflict:
            continue
        selected.append(event)
        for frame in event["merge_frames"]:
            occupied[frame] = event["host_masks"][frame]
    return sorted(selected, key=lambda row: row["entry_t"])


def run(upstream_dir: Path | None, params: dict, out) -> dict:
    if upstream_dir is None:
        raise ValueError("quarantine-stage labels are required")
    labels = load_stack(upstream_dir / f"{params['stem']}.tif")
    trim_dir = Path(params["trim_dir"])
    raw = load_stack(trim_dir / f"{params['stem']}_registered_raw.tif")
    lag = load_stack(trim_dir / f"{params['stem']}_lag01_float.tif")
    candidate = labels.copy()
    events = detect_events(labels, lag, params["merge"],
                           int(params["source_frame_offset"]))
    enabled = bool(params.get("enable_merges", False))
    rows = []
    for index, event in enumerate(events, 1):
        applied = False
        if enabled:
            target = event["target_entry"]
            resident = event["resident_entry"]
            target_exit = event["target_exit"]
            resident_exit = event["resident_exit"]
            span = event["split_t"] - event["entry_t"]
            for frame in event["merge_frames"]:
                alpha = (frame - event["entry_t"]) / span
                target_point = (target["x"] * (1 - alpha)
                                + target_exit["x"] * alpha,
                                target["y"] * (1 - alpha)
                                + target_exit["y"] * alpha)
                resident_point = (resident["x"] * (1 - alpha)
                                  + resident_exit["x"] * alpha,
                                  resident["y"] * (1 - alpha)
                                  + resident_exit["y"] * alpha)
                divided = motion_partition(
                    event["host_masks"][frame], lag, frame, 1.5,
                    int(params["merge"]["minimum_partition_px"]))
                if divided is None:
                    divided = partition_host(
                        raw[frame], event["host_masks"][frame],
                        target_point, resident_point,
                        int(params["merge"]["minimum_partition_px"]))
                target_mask, resident_mask = divided
                candidate[frame][target_mask] = int(event["target_identity"])
                candidate[frame][resident_mask] = int(event["resident_identity"])
            observed_exit = int(target_exit["owner"])
            previous = target_exit["mask"]
            for frame in range(event["split_t"], len(candidate)):
                if frame == event["split_t"]:
                    selected = target_exit
                else:
                    choices = identity_objects(labels[frame], observed_exit)
                    if not choices:
                        break
                    py, px = ndi.center_of_mass(previous)
                    selected = max(choices, key=lambda item: (
                        int(np.count_nonzero(item["mask"] & previous)),
                        -math.hypot(item["x"] - px, item["y"] - py)))
                    if (not np.any(selected["mask"] & previous)
                            and math.hypot(selected["x"] - px,
                                           selected["y"] - py) > 30.0):
                        break
                candidate[frame][selected["mask"]] = int(event["target_identity"])
                previous = selected["mask"]
            applied = True
        rows.append({
            "event_id": f"M{index:04d}",
            "target_identity": event["target_identity"],
            "resident_identity": event["resident_identity"],
            "source_entry_imagej_frame": event["source_entry_imagej_frame"],
            "source_split_imagej_frame": event["source_split_imagej_frame"],
            "merge_source_frames": ";".join(str(frame + 1
                                                  + int(params["source_frame_offset"]))
                                               for frame in event["merge_frames"]),
            "source_blue_coverage": event["source_blue_coverage"],
            "host_red_coverage": event["host_red_coverage"],
            "exit_red_coverage": event["exit_red_coverage"],
            "resident_red_coverage": event["resident_red_coverage"],
            "applied": applied,
        })
    label_path = out.out / f"{params['stem']}.tif"
    event_path = out.out / "merge_events.csv"
    save_stack(label_path, candidate)
    pd.DataFrame(rows).to_csv(event_path, index=False)
    return {
        "outputs": {"labels": label_path, "events": event_path},
        "summary": {
            "enabled": enabled, "detected_events": int(len(rows)),
            "applied_events": int(sum(row["applied"] for row in rows)),
            "changed_label_pixels": int(np.count_nonzero(candidate != labels)),
            "foreground_changed_pixels": int(np.count_nonzero(
                (candidate > 0) != (labels > 0))),
        },
    }


