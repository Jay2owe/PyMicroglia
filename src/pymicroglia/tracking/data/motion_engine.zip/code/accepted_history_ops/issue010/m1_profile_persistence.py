"""Measure whole-movie identity persistence before any end-stage changes."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from project_paths import find_project_root


ROOT = find_project_root(Path(__file__))
import sys
sys.path.insert(0, str(ROOT / "code"))
from common import load_stack  # noqa: E402


def consecutive_runs(indices: np.ndarray) -> list[tuple[int, int]]:
    if len(indices) == 0:
        return []
    runs: list[tuple[int, int]] = []
    start = previous = int(indices[0])
    for value in map(int, indices[1:]):
        if value != previous + 1:
            runs.append((start, previous))
            start = value
        previous = value
    runs.append((start, previous))
    return runs


def centroid(mask: np.ndarray) -> tuple[float, float]:
    yy, xx = np.nonzero(mask)
    return float(np.mean(yy)), float(np.mean(xx))


def profile(labels: np.ndarray, authority: pd.DataFrame, params: dict
            ) -> tuple[pd.DataFrame, pd.DataFrame]:
    offset = int(params["source_frame_offset"])
    cfg = params["profile"]
    window = int(cfg["local_area_window_frames"])
    fraction = float(cfg["deficit_area_fraction"])
    maximum_gap = int(cfg["maximum_bracket_gap_frames"])
    authority_by_id = authority.set_index("identity").to_dict("index")
    profiles: list[dict] = []
    deficits: list[dict] = []
    identities = sorted(set(map(int, np.unique(labels))) - {0})
    for identity in identities:
        areas = np.asarray(
            [np.count_nonzero(frame == identity) for frame in labels], int)
        present = np.flatnonzero(areas > 0)
        runs = consecutive_runs(present)
        auth = authority_by_id.get(identity, {})
        profiles.append({
            "identity": identity,
            "frames_present": int(len(present)),
            "first_output_frame": int(present[0] + 1),
            "last_output_frame": int(present[-1] + 1),
            "first_source_imagej_frame": int(present[0] + 1 + offset),
            "last_source_imagej_frame": int(present[-1] + 1 + offset),
            "span_frames": int(present[-1] - present[0] + 1),
            "run_count": int(len(runs)),
            "maximum_consecutive_frames": int(max(e - s + 1 for s, e in runs)),
            "edge_censored": bool(present[0] == 0 or present[-1] == len(labels) - 1),
            "median_area_px": float(np.median(areas[present])),
            "minimum_area_px": int(np.min(areas[present])),
            "maximum_area_px": int(np.max(areas[present])),
            "total_identity_pixels": int(np.sum(areas)),
            "confidence_layer": auth.get("confidence_layer", "unknown"),
            "priority_rank": auth.get("priority_rank", ""),
            "permanently_birth_small": auth.get("permanently_birth_small", ""),
        })
        if len(present) < int(cfg["persistent_minimum_frames"]):
            continue
        for frame in range(1, len(labels) - 1):
            before = present[present < frame]
            after = present[present > frame]
            if not len(before) or not len(after):
                continue
            previous, following = int(before[-1]), int(after[0])
            gap = following - previous - 1
            if gap > maximum_gap:
                continue
            local = areas[max(0, frame - window):min(len(labels), frame + window + 1)]
            local = local[local > 0]
            if not len(local):
                continue
            reference = float(np.median(local))
            current = int(areas[frame])
            if current > 0 and current >= fraction * reference:
                continue
            prev_y, prev_x = centroid(labels[previous] == identity)
            next_y, next_x = centroid(labels[following] == identity)
            alpha = (frame - previous) / max(following - previous, 1)
            deficits.append({
                "identity": identity,
                "output_frame": frame + 1,
                "source_imagej_frame": frame + 1 + offset,
                "deficit_type": "missing" if current == 0 else "shrunken",
                "current_area_px": current,
                "reference_area_px": reference,
                "area_fraction": current / max(reference, 1.0),
                "previous_anchor_output_frame": previous + 1,
                "next_anchor_output_frame": following + 1,
                "bracket_gap_frames": gap,
                "predicted_y": prev_y + alpha * (next_y - prev_y),
                "predicted_x": prev_x + alpha * (next_x - prev_x),
            })
    return pd.DataFrame(profiles), pd.DataFrame(deficits)

