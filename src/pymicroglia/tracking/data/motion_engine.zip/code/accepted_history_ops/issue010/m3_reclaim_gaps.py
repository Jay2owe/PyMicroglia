"""Globally assign unclaimed components to lower-cost persistent lineages."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import ndimage as ndi
from scipy.optimize import linear_sum_assignment

from project_paths import find_project_root


ROOT = find_project_root(Path(__file__))
import sys
sys.path.insert(0, str(ROOT / "code"))
from common import load_stack, save_stack  # noqa: E402


@dataclass
class Component:
    number: int
    mask: np.ndarray
    area: int
    y: float
    x: float


def components(mask: np.ndarray, minimum_area: int) -> list[Component]:
    numbered, count = ndi.label(mask, structure=np.ones((3, 3), bool))
    result: list[Component] = []
    for number in range(1, count + 1):
        item = numbered == number
        area = int(np.count_nonzero(item))
        if area < minimum_area:
            continue
        yy, xx = np.nonzero(item)
        result.append(Component(number, item, area, float(np.mean(yy)),
                                float(np.mean(xx))))
    return result


def mask_centroid(mask: np.ndarray) -> tuple[float, float]:
    yy, xx = np.nonzero(mask)
    return float(np.mean(yy)), float(np.mean(xx))


def coverage(values: np.ndarray, mask: np.ndarray, predicate) -> float:
    if not np.any(mask):
        return 0.0
    return float(np.mean(predicate(values[mask])))


def motion_support(lag: np.ndarray, frame: int, candidate: np.ndarray,
                   previous: int, following: int, previous_mask: np.ndarray,
                   following_mask: np.ndarray, threshold: float) -> float:
    evidence: list[float] = []
    if previous == frame - 1 and frame > 0:
        transition = lag[frame - 1]
        blue = coverage(transition, previous_mask, lambda x: x <= -threshold)
        red = coverage(transition, candidate, lambda x: x >= threshold)
        evidence.append(min(blue, red))
    if following == frame + 1 and frame < len(lag):
        transition = lag[frame]
        blue = coverage(transition, candidate, lambda x: x <= -threshold)
        red = coverage(transition, following_mask, lambda x: x >= threshold)
        evidence.append(min(blue, red))
    return max(evidence, default=0.0)


def territory_support(candidate: np.ndarray, previous_mask: np.ndarray,
                      following_mask: np.ndarray) -> float:
    history = ndi.binary_dilation(
        previous_mask | following_mask, structure=np.ones((3, 3), bool),
        iterations=3)
    return float(np.count_nonzero(candidate & history) /
                 max(np.count_nonzero(candidate), 1))


def assignment_cost(candidate: np.ndarray, area: int,
                    predicted: tuple[float, float], radius: float,
                    reference_area: float, previous_mask: np.ndarray,
                    following_mask: np.ndarray, motion: float, cfg: dict
                    ) -> tuple[float, dict]:
    y, x = mask_centroid(candidate)
    distance = float(np.hypot(y - predicted[0], x - predicted[1]))
    position = distance / max(radius, 1.0)
    area_term = abs(float(np.log2(max(area, 1) / max(reference_area, 1.0))))
    history = territory_support(candidate, previous_mask, following_mask)
    terms = {
        "distance_px": distance,
        "position_cost": position,
        "area_cost": area_term,
        "territory_support": history,
        "motion_support": motion,
    }
    cost = (
        float(cfg["position_weight"]) * position
        + float(cfg["area_weight"]) * area_term
        + float(cfg["territory_weight"]) * (1.0 - history)
        + float(cfg["motion_weight"]) * (1.0 - motion))
    return cost, terms


def nearest_anchors(present: np.ndarray, frame: int
                    ) -> tuple[int, int] | None:
    before = present[present < frame]
    after = present[present > frame]
    if not len(before) or not len(after):
        return None
    return int(before[-1]), int(after[0])


def reclaim(labels: np.ndarray, ownership: np.ndarray,
            unclaimed_ids: np.ndarray, profiles: pd.DataFrame,
            lag: np.ndarray, params: dict) -> tuple[np.ndarray, np.ndarray,
                                                       pd.DataFrame]:
    result = ownership.copy()
    unclaimed = unclaimed_ids.copy()
    cfg = params["reclaim"]
    minimum_persistence = int(params["persistent_minimum_frames"])
    persistent = profiles.loc[
        profiles.frames_present.astype(int) >= minimum_persistence,
        "identity"].astype(int).tolist()
    areas_by_id = {identity: np.zeros(len(labels), int)
                   for identity in persistent}
    for frame, item in enumerate(labels):
        values, counts = np.unique(item, return_counts=True)
        for value, count in zip(map(int, values), map(int, counts)):
            if value in areas_by_id:
                areas_by_id[value][frame] = count
    present_by_id = {
        identity: np.flatnonzero(areas > 0)
        for identity, areas in areas_by_id.items()}
    mask_cache: dict[tuple[int, int], np.ndarray] = {}

    def identity_mask(frame: int, identity: int) -> np.ndarray:
        key = (frame, identity)
        if key not in mask_cache:
            mask_cache[key] = labels[frame] == identity
        return mask_cache[key]
    maximum_gap = int(cfg["maximum_bracket_gap_frames"])
    minimum_donor = int(cfg["minimum_donor_area_px"])
    threshold = float(cfg["motion_threshold"])
    minimum_improvement = float(cfg["minimum_improvement"])
    actions: list[dict] = []
    for frame in range(len(result)):
        donors = components(unclaimed[frame] > 0, minimum_donor)
        if not donors:
            continue
        edges: list[dict] = []
        recipients: list[int] = []
        states: dict[int, dict] = {}
        for identity in persistent:
            areas = areas_by_id[identity]
            present = present_by_id[identity]
            anchors = nearest_anchors(present, frame)
            if anchors is None:
                continue
            previous, following = anchors
            gap = following - previous - 1
            if gap > maximum_gap:
                continue
            previous_mask = identity_mask(previous, identity)
            following_mask = identity_mask(following, identity)
            py, px = mask_centroid(previous_mask)
            fy, fx = mask_centroid(following_mask)
            alpha = (frame - previous) / max(following - previous, 1)
            predicted = (py + alpha * (fy - py), px + alpha * (fx - px))
            speed = float(np.hypot(fy - py, fx - px) /
                          max(following - previous, 1))
            radius = min(float(cfg["maximum_search_radius_px"]),
                         float(cfg["base_search_radius_px"]) + speed * gap)
            local = areas[max(0, frame - 5):min(len(labels), frame + 6)]
            local = local[local > 0]
            if not len(local):
                continue
            reference_area = float(np.median(local))
            current_mask = result[frame] == identity
            current_area = int(np.count_nonzero(current_mask))
            if current_area:
                current_motion = motion_support(
                    lag, frame, current_mask, previous, following,
                    previous_mask, following_mask, threshold)
                current_cost, current_terms = assignment_cost(
                    current_mask, current_area, predicted, radius,
                    reference_area, previous_mask, following_mask,
                    current_motion, cfg)
            else:
                current_terms = {"distance_px": None, "position_cost": None,
                                 "area_cost": None, "territory_support": 0.0,
                                 "motion_support": 0.0}
                current_cost = 2.5 + float(cfg["gap_weight"]) * gap
            area_fraction = current_area / max(reference_area, 1.0)
            state = {
                "identity": identity, "previous": previous,
                "following": following, "gap": gap,
                "previous_mask": previous_mask,
                "following_mask": following_mask,
                "predicted": predicted, "radius": radius,
                "reference_area": reference_area,
                "current_mask": current_mask, "current_area": current_area,
                "current_cost": current_cost, "current_terms": current_terms,
                "area_fraction": area_fraction,
            }
            states[identity] = state
            for donor_index, donor in enumerate(donors):
                distance = float(np.hypot(donor.y - predicted[0],
                                          donor.x - predicted[1]))
                if distance > radius:
                    continue
                if current_area:
                    separation = float(np.min(
                        ndi.distance_transform_edt(~current_mask)[donor.mask]))
                else:
                    separation = float("inf")
                deficit = area_fraction < float(cfg["area_deficit_fraction"])
                if current_area and deficit and separation <= 3.0:
                    action = "augment"
                    candidate_mask = current_mask | donor.mask
                elif current_area:
                    action = "swap"
                    candidate_mask = donor.mask
                else:
                    action = "fill"
                    candidate_mask = donor.mask
                candidate_area = int(np.count_nonzero(candidate_mask))
                ratio = candidate_area / max(reference_area, 1.0)
                if ratio < 0.25 or ratio > 2.5:
                    continue
                candidate_motion = motion_support(
                    lag, frame, candidate_mask, previous, following,
                    previous_mask, following_mask, threshold)
                candidate_cost, terms = assignment_cost(
                    candidate_mask, candidate_area, predicted, radius,
                    reference_area, previous_mask, following_mask,
                    candidate_motion, cfg)
                candidate_cost += float(cfg["gap_weight"]) * gap
                improvement = current_cost - candidate_cost
                if improvement < minimum_improvement:
                    continue
                edges.append({
                    "recipient": identity, "donor": donor_index,
                    "action": action, "improvement": improvement,
                    "candidate_cost": candidate_cost,
                    "candidate_area": candidate_area,
                    "donor_area": donor.area,
                    "separation_px": separation,
                    **terms,
                })
                if identity not in recipients:
                    recipients.append(identity)
        if not edges:
            continue
        donor_count, recipient_count = len(donors), len(recipients)
        size = donor_count + recipient_count
        matrix = np.zeros((size, size), float)
        edge_by_pair = {(item["donor"], recipients.index(item["recipient"])): item
                        for item in edges}
        for (donor_index, recipient_index), item in edge_by_pair.items():
            matrix[donor_index, recipient_index] = -item["improvement"]
        rows, cols = linear_sum_assignment(matrix)
        chosen = []
        for row, col in zip(rows, cols):
            item = edge_by_pair.get((int(row), int(col)))
            if item is not None and item["improvement"] >= minimum_improvement:
                chosen.append(item)
        for item in sorted(chosen, key=lambda x: -x["improvement"]):
            donor = donors[item["donor"]]
            state = states[item["recipient"]]
            released = 0
            if item["action"] == "swap":
                current = result[frame] == item["recipient"]
                released = int(np.count_nonzero(current))
                result[frame][current] = 0
                unclaimed[frame][current] = item["recipient"]
            result[frame][donor.mask] = item["recipient"]
            unclaimed[frame][donor.mask] = 0
            actions.append({
                "output_frame": frame + 1,
                "source_imagej_frame": frame + 1 + int(
                    params["source_frame_offset"]),
                "recipient_identity": item["recipient"],
                "action": item["action"],
                "donor_original_identities": ";".join(map(str, sorted(
                    set(map(int, np.unique(unclaimed_ids[frame][donor.mask])))
                    - {0}))),
                "donor_area_px": item["donor_area"],
                "released_current_area_px": released,
                "reference_area_px": state["reference_area"],
                "current_area_px": state["current_area"],
                "candidate_area_px": item["candidate_area"],
                "current_cost": state["current_cost"],
                "candidate_cost": item["candidate_cost"],
                "cost_improvement": item["improvement"],
                "distance_px": item["distance_px"],
                "search_radius_px": state["radius"],
                "position_cost": item["position_cost"],
                "area_cost": item["area_cost"],
                "territory_support": item["territory_support"],
                "motion_support": item["motion_support"],
                "bracket_gap_frames": state["gap"],
            })
    columns = [
        "output_frame", "source_imagej_frame", "recipient_identity", "action",
        "donor_original_identities", "donor_area_px",
        "released_current_area_px", "reference_area_px", "current_area_px",
        "candidate_area_px", "current_cost", "candidate_cost",
        "cost_improvement", "distance_px", "search_radius_px",
        "position_cost", "area_cost", "territory_support", "motion_support",
        "bracket_gap_frames",
    ]
    return result, unclaimed, pd.DataFrame(actions, columns=columns)

